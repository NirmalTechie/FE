# Sample Python Project
def main():
    print("Hello, Python Developer!")

if __name__ == "__main__":
    main()
