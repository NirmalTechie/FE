# Useful aliases for Python developers
alias python='python3'
alias pip='pip3'
alias activate='source venv/bin/activate'
alias deact='deactivate'
alias run='python main.py'
alias mkvenv='python -m venv venv && source venv/bin/activate'
